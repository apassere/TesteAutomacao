import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RealizarCompra {

	String url;
	WebDriver driver;
	Actions acao;
	WebDriverWait wait;
	WebElement comboElement;
	String sPNome, sUNome,sSenha, sEndereco, sCidade, sCEP, sCelular, sNomeEndereco, sEmail,sDiaNasc,sMesNasc, sAnoNasc;
	
	
	@Before
	public void Iniciar() {
		
		
		url = "http://automationpractice.com";
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Iterasys\\FTS117\\drivers\\Chrome\\v2.44\\chromedriver.exe");
		
		driver = new ChromeDriver();
		acao = new Actions(driver);
		wait = new WebDriverWait(driver, 10);
		
		sEmail = "t21estedb@dbserver.com.br";
		sPNome = "Alexandre Passere";
		sUNome = "Borges";
		sSenha = "123456";
		sEndereco = "Rua Teste, 533";
		sCidade = "S�o Paulo";
		sCEP = "00000";
		sCelular = "11999998888";
		sNomeEndereco = "Teste";
		sDiaNasc = "12";
		sMesNasc = "1";
		sAnoNasc = "1989";
		sNomeEndereco = "DBServer";
	}
	
	@After
	public void Finalizar() {
		
		//driver.quit();
		
	}
	
	@Test
	
	public void CT01EscolherProduto() throws InterruptedException{
		
		driver.get(url);
	    driver.findElement(By.xpath("(//a[@href='http://automationpractice.com/index.php?id_category=5&controller=category'])[2]")).click();
		acao.moveToElement(driver.findElement(By.xpath("//div[2]/a/span")));
		driver.findElement(By.xpath("//div[2]/a/span")).click();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//div[@id='layer_cart']/div/div[2]/div[4]/a/span")).click();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    //verifica se o item foi inclu�do na lista
	    assertEquals("1", driver.findElement(By.name("quantity_1_1_0_0")).getAttribute("value"));
	    driver.findElement(By.xpath("//div[@id='center_column']/p[2]/a/span")).click();
	    driver.findElement(By.id("email_create")).clear();
		driver.findElement(By.id("email_create")).sendKeys(sEmail);
		driver.findElement(By.id("SubmitCreate")).click();
		
		//preenchimento do formul�rio de cadastro
		driver.findElement(By.id("uniform-id_gender1")).click();
		driver.findElement(By.id("customer_firstname")).clear();
		driver.findElement(By.id("customer_firstname")).sendKeys(sPNome);
		driver.findElement(By.id("customer_lastname")).clear();
		driver.findElement(By.id("customer_lastname")).sendKeys(sUNome);
		driver.findElement(By.id("email")).clear();
		driver.findElement(By.id("email")).sendKeys(sEmail);
		driver.findElement(By.id("passwd")).clear();
		driver.findElement(By.id("passwd")).sendKeys(sSenha);
		Select comboboxDia = new Select(driver.findElement(By.id("days")));
		comboboxDia.selectByValue(sDiaNasc);
		Select comboboxMes = new Select(driver.findElement(By.id("months")));
		comboboxMes.selectByValue(sMesNasc);
		Select comboboxAno = new Select(driver.findElement(By.id("years")));
		comboboxAno.selectByValue(sAnoNasc);
		driver.findElement(By.id("address1")).clear();
		driver.findElement(By.id("address1")).sendKeys(sEndereco);
		driver.findElement(By.id("city")).clear();
		driver.findElement(By.id("city")).sendKeys(sCidade);
		Select comboboxState = new Select(driver.findElement(By.id("id_state")));
		comboboxState.selectByValue("1");
		driver.findElement(By.id("postcode")).clear();
		driver.findElement(By.id("postcode")).sendKeys(sCEP);
		Select comboboxCountry = new Select(driver.findElement(By.id("id_country")));
		comboboxCountry.selectByValue("21");
		driver.findElement(By.id("phone_mobile")).clear();
		driver.findElement(By.id("phone_mobile")).sendKeys(sCelular);
		driver.findElement(By.id("alias")).clear();
		driver.findElement(By.id("alias")).sendKeys(sNomeEndereco);
		driver.findElement(By.id("submitAccount")).click();
		
		//escolher endere�o de entrega
		Select comboEntrega = new Select(driver.findElement(By.id("id_address_delivery")));
		comboEntrega.selectByVisibleText(sNomeEndereco);
		driver.findElement(By.name("processAddress")).click();
				
		//Transportadora
		driver.findElement(By.id("cgv")).click();
		driver.findElement(By.name("processCarrier")).click();
		
		//Forma de Pagamento
		
		driver.findElement(By.linkText("Pay by bank wire (order processing will be longer)")).click();
		driver.findElement(By.xpath("(//button[@type='submit'])[2]")).click();
	    assertEquals("Your order on My Store is complete.", driver.findElement(By.cssSelector("p.cheque-indent > strong.dark")).getText());
	    	    
	    
	}
	
		
}
